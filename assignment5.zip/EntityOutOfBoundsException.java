/* COMP 1406 Summer 2016
 * Assignment 5
 * EntityOutOfBoundsException
 * Zachary Stroud-Taylor
 * 100955368
 * August 9, 2016
 */ 
public class EntityOutOfBoundsException extends Exception{
 
 public EntityOutOfBoundsException(String s){
  super(s);
 }

}